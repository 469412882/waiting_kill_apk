
package com.yuyh.xifengnba.ui.Interactor;

public interface NBANewsInteractor {

    String[] getTabs();
}
