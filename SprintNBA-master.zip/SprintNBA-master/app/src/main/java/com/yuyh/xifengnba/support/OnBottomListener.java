package com.yuyh.xifengnba.support;

public interface OnBottomListener {
    void onBottom();
}