package com.yuyh.xifengnba.ui.presenter;

public interface NewsDetailPresenter {

    void initialized(String arcId);

}
