package com.yuyh.xifengnba.ui.view;

import com.yuyh.xifengnba.http.bean.forum.ForumsData;
import com.yuyh.xifengnba.ui.view.base.BaseView;

import java.util.List;

/**
 * @author yuyh.
 * @date 16/6/25.
 */
public interface ForumListView extends BaseView{

    void showForumList(List<ForumsData.Forum> forumList);
}
