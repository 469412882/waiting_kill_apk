package com.yuyh.xifengnba.http.bean.video;

/**
 * @author yuyh.
 * @date 2016/12/23.
 */
public class VideoLiveInfo {

    public String leftName;

    public String leftImg;

    public String rightName;

    public String rightImg;

    public String startTime;

    public String link;

    public String time;

    public String type;

}
