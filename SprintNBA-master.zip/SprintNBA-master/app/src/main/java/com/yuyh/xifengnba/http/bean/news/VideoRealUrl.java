package com.yuyh.xifengnba.http.bean.news;

/**
 * 腾讯视频真实地址
 *
 * @author yuyh.
 * @date 16/7/1.
 */
public class VideoRealUrl {

    public String url;

    public String fvkey;

    public String vid;

    public String fn;
}
