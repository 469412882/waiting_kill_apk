package com.yuyh.xifengnba.event;

/**
 * 刷新完成
 *
 * @author yuyh.
 * @date 2016/7/6.
 */
public class RefreshCompleteEvent {
    public RefreshCompleteEvent() {
    }
}
