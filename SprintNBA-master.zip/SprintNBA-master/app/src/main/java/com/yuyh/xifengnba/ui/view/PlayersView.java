package com.yuyh.xifengnba.ui.view;

import com.yuyh.xifengnba.http.bean.player.Players;

import java.util.List;

public interface PlayersView {

    void showAllPlayers(List<Players.Player> bean);
    void failure(String msg);

}
