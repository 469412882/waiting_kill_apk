package com.yuyh.xifengnba.ui.view;

import com.yuyh.xifengnba.http.bean.player.Teams;

public interface TeamsView {

    void showAllTeams(Teams.TeamsBean bean);

}
