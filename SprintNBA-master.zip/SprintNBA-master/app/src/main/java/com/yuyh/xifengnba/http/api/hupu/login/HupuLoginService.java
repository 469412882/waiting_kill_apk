package com.yuyh.xifengnba.http.api.hupu.login;

/**
 * @author yuyh.
 * @date 16/6/25.
 */
public class HupuLoginService {
}
