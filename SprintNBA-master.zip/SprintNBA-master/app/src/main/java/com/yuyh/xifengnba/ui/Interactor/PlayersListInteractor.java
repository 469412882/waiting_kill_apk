
package com.yuyh.xifengnba.ui.Interactor;

import com.yuyh.xifengnba.http.bean.player.Players;
import com.yuyh.xifengnba.http.api.RequestCallback;

public interface PlayersListInteractor {

    void getAllPlayers(RequestCallback<Players> callback);
}
