package com.yuyh.xifengnba.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.view.View;
import android.widget.ListView;

import com.yuyh.xifengnba.R;
import com.yuyh.xifengnba.base.BaseSwipeBackCompatActivity;
import com.yuyh.xifengnba.base.BaseWebActivity;
import com.yuyh.xifengnba.http.bean.player.Teams;
import com.yuyh.xifengnba.support.OnListItemClickListener;
import com.yuyh.xifengnba.ui.adapter.TeamsListAdapter;
import com.yuyh.xifengnba.ui.presenter.Presenter;
import com.yuyh.xifengnba.ui.presenter.impl.TeamsListPresenterImpl;
import com.yuyh.xifengnba.ui.view.TeamsView;

import java.util.ArrayList;
import java.util.List;

import butterknife.InjectView;

/**
 * @author yuyh.
 * @date 16/6/11.
 */
public class TeamsListActivity extends BaseSwipeBackCompatActivity implements TeamsView, OnListItemClickListener<Teams.TeamsBean.Team> {

    public static void start(Context context){
        Intent intent = new Intent(context, TeamsListActivity.class);
        context.startActivity(intent);
    }

    @InjectView(R.id.lvAllTeam)
    ListView lvAllTeam;

    private TeamsListAdapter adapter;
    private List<Teams.TeamsBean.Team> list = new ArrayList<>();
    private Presenter presenter;

    @Override
    protected int getContentViewLayoutID() {
        return R.layout.activity_all_team;
    }

    @Override
    protected void initViewsAndEvents() {
        showLoadingDialog();
        setTitle("球队列表");
        adapter = new TeamsListAdapter(list, this, R.layout.item_list_teams);
        adapter.setOnListItemClickListener(this);
        lvAllTeam.setAdapter(adapter);
        presenter = new TeamsListPresenterImpl(this, this);
        presenter.initialized();
    }

    @Override
    public void showAllTeams(Teams.TeamsBean bean) {
        list.clear();
        list.addAll(bean.east);
        list.addAll(bean.west);
        adapter.notifyDataSetChanged();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingDialog();
            }
        }, 1000);
    }

    @Override
    public void onItemClick(View view, int position, Teams.TeamsBean.Team data) {
        BaseWebActivity.start(this, data.detailUrl, data.fullCnName, true, true);
    }
}
