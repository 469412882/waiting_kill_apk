package com.yuyh.xifengnba.ui.view;

import com.yuyh.xifengnba.http.bean.match.MatchStat;
import com.yuyh.xifengnba.ui.view.base.BaseView;

import java.util.List;

/**
 * @author yuyh.
 * @date 2016/7/5.
 */
public interface MatchPlayerDataView extends BaseView {

    void showPlayerData(List<MatchStat.PlayerStats> playerStatses);
}
