package com.yuyh.xifengnba.ui.view;

/**
 * @author yuyh.
 * @date 2016/7/26.
 */
public interface ImagePreView {
}
