package com.yuyh.xifengnba.event;

/**
 * @author yuyh.
 * @date 2016/6/28.
 */
public class ThreadContentEvent {

    public ThreadContentEvent() {

    }
}
