package com.yuyh.xifengnba.ui.view;

import com.yuyh.xifengnba.http.bean.news.NewsDetail;

public interface NewsDetailView {

    void showNewsDetail(NewsDetail newsDetail);

}
