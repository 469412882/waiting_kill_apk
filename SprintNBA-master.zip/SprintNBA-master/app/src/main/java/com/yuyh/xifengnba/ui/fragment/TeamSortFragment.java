package com.yuyh.xifengnba.ui.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.view.View;

import com.cjj.MaterialRefreshLayout;
import com.cjj.MaterialRefreshListener;
import com.yuyh.library.utils.DateUtils;
import com.yuyh.library.utils.DimenUtils;
import com.yuyh.library.utils.log.LogUtils;
import com.yuyh.xifengnba.R;
import com.yuyh.xifengnba.base.BaseLazyFragment;
import com.yuyh.xifengnba.base.BaseWebActivity;
import com.yuyh.xifengnba.http.bean.player.TeamsRank;
import com.yuyh.xifengnba.support.OnListItemClickListener;
import com.yuyh.xifengnba.support.SpaceItemDecoration;
import com.yuyh.xifengnba.support.SupportRecyclerView;
import com.yuyh.xifengnba.ui.adapter.TeamsRankAdapter;
import com.yuyh.xifengnba.ui.presenter.impl.TeamSortPresenter;
import com.yuyh.xifengnba.ui.view.TeamSortView;

import java.util.ArrayList;
import java.util.List;

import butterknife.InjectView;

/**
 * @author yuyh.
 * @date 16/6/5.
 */
public class TeamSortFragment extends BaseLazyFragment implements TeamSortView {

    private String date = "";

    @InjectView(R.id.refresh)
    MaterialRefreshLayout materialRefreshLayout;
    @InjectView(R.id.recyclerview)
    SupportRecyclerView recyclerView;
    @InjectView(R.id.emptyView)
    View emptyView;

    private TeamsRankAdapter adapter;
    private List<TeamsRank.TeamBean> list = new ArrayList<>();

    private TeamSortPresenter presenter;

    @Override
    protected void onCreateViewLazy(Bundle savedInstanceState) {
        super.onCreateViewLazy(savedInstanceState);
        setContentView(R.layout.fragment_normal_recyclerview);

        date = DateUtils.format(System.currentTimeMillis(), "yyyy-MM-dd");
        LogUtils.i(date);

        mActivity.invalidateOptionsMenu();

        initView();
        presenter = new TeamSortPresenter(mActivity, this);
        presenter.requestTeamsRank(false);
    }

    private void initView() {
        adapter = new TeamsRankAdapter(list, mActivity, R.layout.item_fragment_teamsort_entity, R.layout.item_fragment_teamsort_title);
        adapter.setOnItemClickListener(new OnListItemClickListener<TeamsRank.TeamBean>() {
            @Override
            public void onItemClick(View view, int position, TeamsRank.TeamBean data) {
                BaseWebActivity.start(mActivity, data.detailUrl, data.name, true, true);
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(recyclerView.getContext()));
        recyclerView.setAdapter(adapter);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new SpaceItemDecoration(DimenUtils.dpToPxInt(1)));
        materialRefreshLayout.setMaterialRefreshListener(new RefreshListener());
        materialRefreshLayout.setLoadMore(false);
    }

    @Override
    public void showTeamSort(List<TeamsRank.TeamBean> teamlist) {
        list.clear();
        list.addAll(teamlist);
        complete();
    }

    @Override
    public void showLoading(String msg) {
        showLoadingDialog();
    }

    @Override
    public void hideLoading() {
        hideLoadingDialog();
    }

    @Override
    public void showError(String msg) {
        hideLoading();
        complete();
    }

    private class RefreshListener extends MaterialRefreshListener {
        @Override
        public void onRefresh(final MaterialRefreshLayout materialRefreshLayout) {
            presenter.requestTeamsRank(true);
        }
    }

    private void complete() {
        recyclerView.setEmptyView(emptyView);
        adapter.notifyDataSetChanged();
        materialRefreshLayout.finishRefresh();
        materialRefreshLayout.finishRefreshLoadMore();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadingDialog();
            }
        }, 800);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser && mActivity != null) {
            mActivity.invalidateOptionsMenu();
        }
    }

    @Override
    protected void onDestroyViewLazy() {
        super.onDestroyViewLazy();
    }
}
