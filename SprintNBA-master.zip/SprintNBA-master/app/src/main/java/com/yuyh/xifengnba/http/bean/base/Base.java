package com.yuyh.xifengnba.http.bean.base;

import java.io.Serializable;

/**
 * @author yuyh.
 * @date 16/6/4.
 */
public class Base implements Serializable {

    public int code;
    public String version;
}
