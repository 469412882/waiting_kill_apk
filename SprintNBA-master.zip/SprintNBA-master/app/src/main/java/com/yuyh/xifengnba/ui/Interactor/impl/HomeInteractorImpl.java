package com.yuyh.xifengnba.ui.Interactor.impl;

import android.content.Context;

import com.yuyh.xifengnba.ui.Interactor.HomeInteractor;
import com.yuyh.xifengnba.R;
import com.yuyh.xifengnba.base.BaseLazyFragment;
import com.yuyh.xifengnba.utils.NavigationEntity;
import com.yuyh.xifengnba.ui.fragment.ForumListFragment;
import com.yuyh.xifengnba.ui.fragment.NewsFragment;
import com.yuyh.xifengnba.ui.fragment.ScheduleFragment;
import com.yuyh.xifengnba.ui.fragment.StatsRankFragment;
import com.yuyh.xifengnba.ui.fragment.TeamSortFragment;
import com.yuyh.xifengnba.ui.fragment.OtherFragment;

import java.util.ArrayList;
import java.util.List;

public class HomeInteractorImpl implements HomeInteractor {

    @Override
    public List<BaseLazyFragment> getPagerFragments() {
        List<BaseLazyFragment> fragments = new ArrayList<BaseLazyFragment>() {{
            add(new NewsFragment());
            add(new ScheduleFragment());
            add(new TeamSortFragment());
            add(new StatsRankFragment());
            add(new ForumListFragment());
            add(new OtherFragment());
        }};
        return fragments;
    }

    @Override
    public List<NavigationEntity> getNavigationList(Context context) {
        List<NavigationEntity> navigationEntities = new ArrayList<NavigationEntity>() {{
            add(new NavigationEntity(R.drawable.ic_top_news, "NBA头条"));
            add(new NavigationEntity(R.drawable.ic_videos, "赛事直播"));
            add(new NavigationEntity(R.drawable.ic_score, "球队战绩"));
            add(new NavigationEntity(R.drawable.ic_sort, "数据排行"));
            add(new NavigationEntity(R.drawable.ic_hupu, "虎扑专区"));
            add(new NavigationEntity(R.drawable.ic_others, "其他"));
        }};
        return navigationEntities;
    }
}
