package com.yuyh.xifengnba.ui.view;

import com.yuyh.xifengnba.base.BaseLazyFragment;
import com.yuyh.xifengnba.utils.NavigationEntity;

import java.util.List;

public interface HomeView {

    void initializeViews(List<BaseLazyFragment> fragments, List<NavigationEntity> navigationList);

}
