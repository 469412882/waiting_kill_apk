package com.yuyh.xifengnba.ui.view;

import com.yuyh.xifengnba.http.bean.match.LiveDetail;

import java.util.List;

/**
 * @author yuyh.
 * @date 16/7/2.
 */
public interface MatchLiveView {

    void addList(List<LiveDetail.LiveContent> detail, boolean front);

    void showError(String message);
}
