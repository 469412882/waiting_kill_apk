package com.yuyh.xifengnba.ui.Interactor.impl;

import com.yuyh.xifengnba.ui.Interactor.TeamsListInteractor;
import com.yuyh.xifengnba.http.api.tencent.TencentService;
import com.yuyh.xifengnba.http.bean.player.Teams;
import com.yuyh.xifengnba.http.api.RequestCallback;

/**
 * @author yuyh.
 * @date 16/6/24.
 */
public class TeamsListListInteractorImpl implements TeamsListInteractor {

    @Override
    public void getAllTeams(RequestCallback<Teams> callback) {
        TencentService.getTeamList(false, callback);
    }
}
