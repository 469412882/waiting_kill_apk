package com.yuyh.xifengnba.http.bean.forum;

import java.io.Serializable;

public class AttendStatusData implements Serializable{
    public int attendStatus;
    public int status;
    public ForumsData.Forum forumInfo;
}
