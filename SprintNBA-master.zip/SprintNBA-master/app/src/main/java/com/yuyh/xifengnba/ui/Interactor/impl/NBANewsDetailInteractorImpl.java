package com.yuyh.xifengnba.ui.Interactor.impl;

import com.yuyh.xifengnba.ui.Interactor.NBANewsDetailInteractor;
import com.yuyh.xifengnba.http.api.tencent.TencentService;
import com.yuyh.xifengnba.http.bean.news.NewsDetail;
import com.yuyh.xifengnba.http.api.RequestCallback;
import com.yuyh.xifengnba.app.Constant;

/**
 * @author yuyh.
 * @date 16/6/11.
 */
public class NBANewsDetailInteractorImpl implements NBANewsDetailInteractor {
    @Override
    public void getNewsDetail(String arcId, RequestCallback<NewsDetail> callback) {
        TencentService.getNewsDetail(Constant.NewsType.BANNER, arcId, false, callback);
    }
}
