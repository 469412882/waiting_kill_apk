package com.yuyh.xifengnba.ui.view;

import com.yuyh.xifengnba.http.bean.player.TeamsRank;
import com.yuyh.xifengnba.ui.view.base.BaseView;

import java.util.List;

/**
 * @author yuyh.
 * @date 2016/7/5.
 */
public interface TeamSortView extends BaseView {

    void showTeamSort(List<TeamsRank.TeamBean> list);
}
