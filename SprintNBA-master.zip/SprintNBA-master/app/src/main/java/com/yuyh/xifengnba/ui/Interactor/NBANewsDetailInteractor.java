
package com.yuyh.xifengnba.ui.Interactor;

import com.yuyh.xifengnba.http.bean.news.NewsDetail;
import com.yuyh.xifengnba.http.api.RequestCallback;

public interface NBANewsDetailInteractor {

    void getNewsDetail(String arcId, RequestCallback<NewsDetail> callback);
}
