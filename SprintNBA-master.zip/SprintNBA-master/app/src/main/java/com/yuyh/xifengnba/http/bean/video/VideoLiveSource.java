package com.yuyh.xifengnba.http.bean.video;

/**
 * @author yuyh.
 * @date 2016/12/24.
 */
public class VideoLiveSource {

    public String link;

    public String name;

}
