package com.yuyh.xifengnba.ui.presenter;

public interface Presenter {

    void initialized();

}
