
package com.yuyh.xifengnba.ui.Interactor;

import android.content.Context;

import com.yuyh.xifengnba.base.BaseLazyFragment;
import com.yuyh.xifengnba.utils.NavigationEntity;

import java.util.List;

public interface HomeInteractor {

    List<BaseLazyFragment> getPagerFragments();

    List<NavigationEntity> getNavigationList(Context context);
}
