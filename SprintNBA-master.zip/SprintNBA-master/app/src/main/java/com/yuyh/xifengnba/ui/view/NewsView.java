package com.yuyh.xifengnba.ui.view;

public interface NewsView {

    void initializeViews(String[] names);
}
