package com.yuyh.xifengnba.event;

/**
 * Fragment刷新
 * @author yuyh.
 * @date 2016/7/5.
 */
public class RefreshEvent {

    public RefreshEvent() {
    }
}
