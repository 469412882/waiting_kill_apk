
package com.yuyh.xifengnba.ui.Interactor;

import com.yuyh.xifengnba.http.bean.player.Teams;
import com.yuyh.xifengnba.http.api.RequestCallback;

public interface TeamsListInteractor {

    void getAllTeams(RequestCallback<Teams> callback);
}
