package com.yuyh.xifengnba.ui.Interactor.impl;

import com.yuyh.xifengnba.ui.Interactor.PlayersListInteractor;
import com.yuyh.xifengnba.http.api.tencent.TencentService;
import com.yuyh.xifengnba.http.bean.player.Players;
import com.yuyh.xifengnba.http.api.RequestCallback;

/**
 * @author yuyh.
 * @date 16/6/24.
 */
public class PlayersListListInteractorImpl implements PlayersListInteractor {

    @Override
    public void getAllPlayers(RequestCallback<Players> callback) {
        TencentService.getPlayerList(false, callback);
    }
}
