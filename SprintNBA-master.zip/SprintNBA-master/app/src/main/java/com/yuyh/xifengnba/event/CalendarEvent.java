package com.yuyh.xifengnba.event;

/**
 * @author yuyh.
 * @date 16/6/11.
 */
public class CalendarEvent {

    String date;

    public CalendarEvent(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }
}
