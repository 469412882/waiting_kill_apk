package com.yuyh.library.utils.data.cipher;

/**
 * @author yuyh.
 * @date 16/4/9.
 */
public abstract class Cipher implements Encrypt,Decrypt{

}
