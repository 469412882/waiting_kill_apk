package com.yuyh.library.view.listener;

public interface OnCancelListener {
	void onCancel();
}