package com.yuyh.library.utils.data.cipher;

/**
 * @author yuyh.
 * @date 16/4/9.
 */
public interface Encrypt {
    byte[] encrypt(byte[] res);
}
