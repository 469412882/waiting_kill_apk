package com.yuyh.library.view.listener;

public interface OnRefreshListener {
	void onRefresh();
}