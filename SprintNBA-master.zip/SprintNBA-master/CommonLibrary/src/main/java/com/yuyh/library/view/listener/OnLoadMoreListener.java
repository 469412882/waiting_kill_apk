package com.yuyh.library.view.listener;

public interface OnLoadMoreListener {
    void onLoadMore();
}