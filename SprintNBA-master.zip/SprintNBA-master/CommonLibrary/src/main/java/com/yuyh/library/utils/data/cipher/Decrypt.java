package com.yuyh.library.utils.data.cipher;

/**
 * @author yuyh.
 * @date 16/4/9.
 */
public interface Decrypt {
    byte[] decrypt(byte[] res);
}
